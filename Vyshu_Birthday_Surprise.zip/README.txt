VYSHU BIRTHDAY SURPRISE

This folder contains index.html, the birthday surprise website.

HOW TO MAKE IT LIVE (FREE):
1. Sign in to GitHub and create a new PUBLIC repository, for example: vyshu-birthday.
2. Upload index.html from this folder to the repository's main/root folder.
3. In the repository, open Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch; choose branch 'main' and folder '/ (root)', then Save.
5. Wait for GitHub Pages to publish. Your website address will look like:
   https://YOUR-GITHUB-USERNAME.github.io/vyshu-birthday/
6. Open that address on your phone and test password: VYRAM 4445.
7. Create a QR code using that exact published URL. Do not use a local file:// address; it will not work on other phones.

The password is a simple on-page gate, not secure authentication. Anyone who can inspect the page source can discover it.
